//
//  ViewController.swift
//  ZhongHao_4.1
//
//  Created by Hao Zhong on 8/10/21.
//

import UIKit

class ViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return playingDeck.numOfCards
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "Image_cell", for: indexPath) as! ImageCollectionViewCell
        
        cell.imageView.image = UIImage(imageLiteralResourceName: "\(playingDeck.cards[indexPath.item].imageName)")
        
        cell.backgroundColor = .white
        cell.layer.cornerRadius = 10
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let width = view.frame.width
        let height = view.frame.height
        var length = width * 0.2
        
        if self.traitCollection.userInterfaceIdiom == .pad {
            if height > width {
                length = width * 0.14
            } else {
                length = height * 0.14
            }
        } else if self.traitCollection.verticalSizeClass == .compact {
            length = height * 0.2
        }
        
        return CGSize(width: length, height: length)
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        // Get the user selected cell
        let cell = collectionView.cellForItem(at: indexPath) as! ImageCollectionViewCell
        
        // Flip the card if it is not flipped
        if playingDeck.cards[indexPath.item].isFlipped == false {
            cell.flip()
            playingDeck.cards[indexPath.item].isFlipped = true
            
            if openCard == nil {
                openCard = indexPath
            } else {
                compareCards(indexPath)
                openCard = nil
            }
        }
        
    }
    
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var gameOverLabel: UILabel!
    @IBOutlet weak var playButton: UIBarButtonItem!
    @IBOutlet weak var timerDisplay: UIBarButtonItem!
    @IBOutlet weak var timerLabel: UILabel!
    
    var playingDeck = Deck(24)
    var remainingCards = 24
    var timer: Timer?
    var countDownFive: Float = 500 // Five seconds
    var gameTime: Float = 0
    var openCard: IndexPath? = nil
    let screen: CGRect = UIScreen.main.bounds
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        let bound = screen.height + screen.width
        if self.traitCollection.userInterfaceIdiom == .pad {
            playingDeck = Deck(40)
            remainingCards = 40
        } else if bound < 1151 {
            playingDeck = Deck(20)
            remainingCards = 20
        }
        if self.traitCollection.verticalSizeClass == .compact {
            timerDisplay.isEnabled = false
        }
        collectionView.isUserInteractionEnabled = false
        
        
    }

    override func traitCollectionDidChange(_ previousTraitCollection: UITraitCollection?) {
        if self.traitCollection.verticalSizeClass == .compact {
            timerDisplay.isEnabled = false
        } else {
            timerDisplay.isEnabled = true
        }
    }
    
    @IBAction func startOrNewGame(_ sender: UIBarButtonItem) {
        if playButton.title == "Start" {
            playButton.title = "New Game"
            for eachCell in collectionView.visibleCells {
                let cell = eachCell as? ImageCollectionViewCell
                cell?.flip()
            }
            
            timer = Timer.scheduledTimer(timeInterval: 0.01, target: self, selector: #selector(countingDown), userInfo: nil, repeats: true)
            
        } else {
            playButton.title = "Start"
            
            playingDeck = Deck(playingDeck.numOfCards)
            remainingCards = playingDeck.numOfCards
            collectionView.reloadData()
            collectionView.isUserInteractionEnabled = false
            openCard = nil
            
            timer?.invalidate()
            countDownFive = 500
            gameTime = 0
            gameOverLabel.isHidden = true
        }
    }
    
    @objc func countingDown() {
        countDownFive -= 1
        let seconds = String(format: "%.2f", countDownFive/100)
        timerDisplay?.title = "Starts in: \(seconds)"
        timerLabel?.text = "Starts in: \n\(seconds)"
        
        if countDownFive <= 0 {
            timer?.invalidate()
            
            for eachCell in collectionView.visibleCells {
                let cell = eachCell as? ImageCollectionViewCell
                cell?.flipBack(0)
            }
            
            timer = Timer.scheduledTimer(timeInterval: 0.01, target: self, selector: #selector(timeElapsed), userInfo: nil, repeats: true)
        }
    }
    
    @objc func timeElapsed() {
        collectionView.isUserInteractionEnabled = true
        gameTime += 1
        let seconds = String(format: "%.2f", gameTime/100)
        timerDisplay?.title = "Time Elapsed: \(seconds)"
        timerLabel?.text = "Time Elapsed: \n\(seconds)\nseconds"
    }
    
    func compareCards(_ secondSelectedCard: IndexPath) {
        let cellOne = collectionView.cellForItem(at: openCard!) as? ImageCollectionViewCell
        let cellTwo = collectionView.cellForItem(at: secondSelectedCard) as? ImageCollectionViewCell
        
        
        if playingDeck.cards[openCard!.item].imageName == playingDeck.cards[secondSelectedCard.item].imageName {
            cellOne?.remove()
            remainingCards -= 1
            
            cellTwo?.remove()
            remainingCards -= 1
            
            checkGameOver()
        } else {
            cellOne?.flipBack(0.7)
            playingDeck.cards[openCard!.item].isFlipped = false
            
            cellTwo?.flipBack(0.7)
            playingDeck.cards[secondSelectedCard.item].isFlipped = false
        }
    }
    
    func checkGameOver() {
        if remainingCards <= 0 {
            timer?.invalidate()
            gameOverLabel.text = "Congrats, you won!\n\nTime Used:\n\n\(String(format: "%.2f", gameTime/100)) seconds"
            gameOverLabel.isHidden = false
        }
    }
}

